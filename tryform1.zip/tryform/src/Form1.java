import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import net.miginfocom.swing.*;
/*
 * Created by JFormDesigner on Sat Aug 01 20:08:23 PDT 2020
 */



/**
 * @author unknown
 */
public class Form1 extends JPanel {

    public String catcode2;

    public Form1() {
        initComponents();
    }

    Connection con1;
    PreparedStatement insert;

    public void updatetable() throws ClassNotFoundException, SQLException {

        int c;
        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/inventory", "root", "");

        insert = con1.prepareStatement("select * from category");
        ResultSet rs = insert.executeQuery();

        ResultSetMetaData Res = rs.getMetaData();
        c= Res.getColumnCount();

        DefaultTableModel df = (DefaultTableModel)table1.getModel();
        df.setRowCount(0);

        while(rs.next()){
            Vector v2 = new Vector();

            for (int a=1; a<=c; a++){
                v2.add(rs.getString("catcode"));
                v2.add(rs.getString("catdesc"));

            }
            df.addRow(v2);
        }
    }

    private void addBtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        // TODO add your code here

        String catcode, catdesc;

        catcode=catcodeTF.getText();
        catdesc=catdescTF.getText();

        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/inventory", "root", "");

        if(e.getSource()==addBtn){
           insert=con1.prepareStatement("select * from category where catcode = ?");
           insert.setString(1, catcode);

            ResultSet rs = insert.executeQuery();

            if (rs.isBeforeFirst()){
                JOptionPane.showMessageDialog(null,"the catcode you are trying to enter already exist ");
                catcodeTF.setText("");
                catdescTF.setText("");
                catcodeTF.requestFocus();

                return;
            }

            insert=con1.prepareStatement("insert into category value (?,?)");

            insert.setString(1, catcode);
            insert.setString(2, catdesc);
            insert.executeUpdate();

            JOptionPane.showMessageDialog(null,"Record added");
            catcodeTF.setText("");
            catdescTF.setText("");
            catcodeTF.requestFocus();


            updatetable();

        }

        if (e.getSource()==table1){}

    }

    private void updateBtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        // TODO add your code here

        String catcode, catdesc;

        catcode=catcodeTF.getText();
        catdesc=catdescTF.getText();

        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/inventory", "root", "");

        insert= con1.prepareStatement("update category set catcode =?, catdesc =? where catcode=?");

        insert.setString(1, catcode);
        insert.setString(2, catdesc);
        insert.setString(3, catcode2);

        insert.executeUpdate();

        JOptionPane.showMessageDialog(null, "Record edited");

        catcodeTF.setText("");
        catdescTF.setText("");
        catcodeTF.requestFocus();

        updatetable();


    }

    private void deleteBtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        // TODO add your code here

        String catcode, catdesc;

        catcode=catcodeTF.getText();
        catdesc=catdescTF.getText();

        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/inventory", "root", "");

        int result = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete?", "Delete", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        
        if (result==JOptionPane.YES_OPTION){
            insert = con1.prepareStatement("delete from category where catcode =? ");
            insert.setString(1, catcode2);
        }
        
        insert.execute();
        JOptionPane.showMessageDialog(null, "Recorded deleted");
        catcodeTF.setText("");
        catdescTF.setText("");
        catcodeTF.requestFocus();
        
        updatetable();


    }

    private void scrollPane1MouseClicked(MouseEvent e) {
        // TODO add your code here
    }

    private void table1MouseClicked(MouseEvent e) {
        // TODO add your code here
        
        DefaultTableModel df = (DefaultTableModel)table1.getModel();
        
        int index1 = table1.getSelectedRow();
        
        catcodeTF.setText(df.getValueAt(index1, 0).toString());
        catcode2 = catcodeTF.getText();
        catdescTF.setText(df.getValueAt(index1,1).toString());
        
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - thy nguyen
        label1 = new JLabel();
        catcodeTF = new JTextField();
        label2 = new JLabel();
        catdescTF = new JTextField();
        scrollPane1 = new JScrollPane();
        table1 = new JTable();
        addBtn = new JButton();
        updateBtn = new JButton();
        deleteBtn = new JButton();

        //======== this ========
        setBorder(new javax.swing.border.CompoundBorder(new javax.swing.border.TitledBorder(new javax
        .swing.border.EmptyBorder(0,0,0,0), "JF\u006frmDesi\u0067ner Ev\u0061luatio\u006e",javax.swing
        .border.TitledBorder.CENTER,javax.swing.border.TitledBorder.BOTTOM,new java.awt.
        Font("Dialo\u0067",java.awt.Font.BOLD,12),java.awt.Color.red
        ), getBorder())); addPropertyChangeListener(new java.beans.PropertyChangeListener(){@Override
        public void propertyChange(java.beans.PropertyChangeEvent e){if("borde\u0072".equals(e.getPropertyName(
        )))throw new RuntimeException();}});
        setLayout(new MigLayout(
            "hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]",
            // rows
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]"));

        //---- label1 ----
        label1.setText("enter the cat code");
        add(label1, "cell 1 1");

        //---- catcodeTF ----
        catcodeTF.setColumns(5);
        add(catcodeTF, "cell 3 1");

        //---- label2 ----
        label2.setText("enter the cat desc");
        add(label2, "cell 1 2");

        //---- catdescTF ----
        catdescTF.setColumns(20);
        add(catdescTF, "cell 3 2");

        //======== scrollPane1 ========
        {

            //---- table1 ----
            table1.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    table1MouseClicked(e);
                }
            });
            scrollPane1.setViewportView(table1);
        }
        add(scrollPane1, "cell 3 3");

        //---- addBtn ----
        addBtn.setText("ADD");
        addBtn.addActionListener(e -> addBtnActionPerformed(e));
        add(addBtn, "cell 3 4");

        //---- updateBtn ----
        updateBtn.setText("UPDATE");
        updateBtn.addActionListener(e -> updateBtnActionPerformed(e));
        add(updateBtn, "cell 3 5");

        //---- deleteBtn ----
        deleteBtn.setText("DELETE");
        deleteBtn.addActionListener(e -> deleteBtnActionPerformed(e));
        add(deleteBtn, "cell 3 6");
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - thy nguyen
    private JLabel label1;
    private JTextField catcodeTF;
    private JLabel label2;
    private JTextField catdescTF;
    private JScrollPane scrollPane1;
    private JTable table1;
    private JButton addBtn;
    private JButton updateBtn;
    private JButton deleteBtn;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    
    
    public void Prepare(){
        
        String [] cols = {"category code", "category description"};
        String [][] data = {{"b1", "b2"}};

        DefaultTableModel model = new DefaultTableModel(data, cols);
        table1.setModel(model);
        
    }

    public static void main(String[] args) {
        Form1 obj = new Form1();
        obj.Prepare();
        obj.setVisible(true);

    }
    
    
    
}
