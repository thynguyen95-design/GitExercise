package com.company;

import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;


class Form1Test {
    private static final String SQL_INSERT = "";
    Connection con1 = getConnection();

    Form1Test() throws SQLException {
    }
    // connection.setAutoCommit(false)

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost/loan", "root", "");

    }


    @Test
    void main() throws SQLException {
       

    }

    @Test
    void prepare() {

    }

    @Test
    void updateTable() {
    }
}