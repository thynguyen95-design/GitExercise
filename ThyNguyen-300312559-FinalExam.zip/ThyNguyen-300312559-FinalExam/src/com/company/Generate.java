package com.company;

public interface Generate {

    public abstract void generateTable();
}
