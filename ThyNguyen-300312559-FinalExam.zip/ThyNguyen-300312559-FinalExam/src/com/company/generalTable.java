package com.company;

public interface generalTable {
}
