package com.company;

public class Personal extends Form1 implements Generate {

    private String clientno;
    private String clientname;
    private double loanamount;
    private int years;


    static final double monthlyRate = .06;
    static final int termInMonths = 12;


    @Override
    public void generateTable() {
        double monthlyPayment = (loanamount*monthlyRate)/(1-Math.pow(1+monthlyRate, -termInMonths));

    }
}
