package com.company;

public class Personal {
}
