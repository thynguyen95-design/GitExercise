/*
 * Created by JFormDesigner on Tue Aug 11 12:30:52 PDT 2020
 */

package com.company;

import java.awt.event.*;
import java.sql.*;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import net.miginfocom.swing.*;

/**
 * @author thy nguyen
 */
public class Form1 extends JFrame {

    Connection con1 ;
    PreparedStatement pst1 ;
    public String clientno2;


    public Form1() {
        initComponents();
    }

    private void addBtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        // TODO add your code here

        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/loan", "root", "");

        ResultSet rs1= pst1.executeQuery();
        pst1 = con1.prepareStatement("INSERT INTO loantable VALUES (?,?,?,?,?)");
        pst1.setString(1, clientnoTF.getText());
        pst1.setString(2, clientnameTF.getText());
        pst1.setString(3, loanamountTF.getText());
        pst1.setString(4, yearsTF.getText());
        pst1.setString(5, loantypeCB.getSelectedItem().toString());

        pst1.executeUpdate();
        JOptionPane.showMessageDialog(null, "Record added");

        clientnoTF.setText("");
        clientnameTF.setText("");
        loanamountTF.setText("");
        yearsTF.setText("");
        loantypeCB.setSelectedIndex(-1);
        clientnoTF.requestFocus();


        updateTable();

    }

    private void scrollPane1MousePressed(MouseEvent e) {
        // TODO add your code here

        DefaultTableModel df = (DefaultTableModel)table1.getModel();
        int index1 = table1.getSelectedRow();

        clientnoTF.setText(df.getValueAt(index1,0).toString());
        clientnameTF.setText(df.getValueAt(index1,1).toString());
        loanamountTF.setText(df.getValueAt(index1,2).toString());
        yearsTF.setText(df.getValueAt(index1,3).toString());
        loantypeCB.setSelectedIndex(-1);

        clientnoTF.getText();




        clientno2=clientnoTF.getText();

    }

    private void editBtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        // TODO add your code here

        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/loan", "root", "");
        pst1 = con1.prepareStatement("UPDATE loantable SET clientno=?, clientname=?,loanamount =?, years =?, loantype =? WHERE clientno=?");

        pst1.setString(1,clientnoTF.getText());
        pst1.setString(2,clientnameTF.getText());
        pst1.setString(3,loanamountTF.getText());
        pst1.setString(4,yearsTF.getText());
        pst1.setString(5,loantypeCB.getSelectedItem().toString());

        //new text-field updated
        pst1.setString(6,clientno2);
        pst1.executeUpdate();


        JOptionPane.showMessageDialog(null, "Record edited");

        clientnoTF.setText("");
        clientnameTF.setText("");
        loanamountTF.setText("");
        yearsTF.setText("");
        loantypeCB.setSelectedIndex(-1);
        clientnoTF.requestFocus();


        updateTable();


    }

    private void deleteBtnActionPerformed(ActionEvent e) throws ClassNotFoundException, SQLException {
        // TODO add your code here

        Class.forName("com.mysql.jdbc.Driver");
        con1 = DriverManager.getConnection("jdbc:mysql://localhost/loan", "root", "");

        int result = JOptionPane.showConfirmDialog(null, "Do you really want to delete this record?", "Delete",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);


        if (result == JOptionPane.YES_OPTION){
            pst1=con1.prepareStatement("DELETE FROM loantable WHERE clientno=?");
            //DELETE FROM `loantable` WHERE 0
            pst1.setString(1,clientno2);
        }
        pst1.executeUpdate();
         //pst1.execute();

        JOptionPane.showMessageDialog(null,"Record deleted");
        clientnoTF.setText("");
        clientnameTF.setText("");
        loanamountTF.setText("");
        yearsTF.setText("");
        loantypeCB.setSelectedIndex(-1);
        clientnoTF.requestFocus();

        updateTable();




    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - thy nguyen
        label1 = new JLabel();
        clientnoTF = new JTextField();
        label2 = new JLabel();
        clientnameTF = new JTextField();
        label3 = new JLabel();
        loanamountTF = new JTextField();
        label4 = new JLabel();
        yearsTF = new JTextField();
        label5 = new JLabel();
        loantypeCB = new JComboBox<>();
        scrollPane1 = new JScrollPane();
        table1 = new JTable();
        scrollPane2 = new JScrollPane();
        table2 = new JTable();
        addBtn = new JButton();
        editBtn = new JButton();
        deleteBtn = new JButton();
        label6 = new JLabel();
        paymentTF = new JTextField();

        //======== this ========
        var contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[68,fill]",
            // rows
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]"));

        //---- label1 ----
        label1.setText("Enter the client number: ");
        contentPane.add(label1, "cell 1 1");

        //---- clientnoTF ----
        clientnoTF.setColumns(20);
        contentPane.add(clientnoTF, "cell 8 1");

        //---- label2 ----
        label2.setText("Enter the client name: ");
        contentPane.add(label2, "cell 1 2");

        //---- clientnameTF ----
        clientnameTF.setColumns(20);
        contentPane.add(clientnameTF, "cell 8 2");

        //---- label3 ----
        label3.setText("Enter the customer loan amount");
        contentPane.add(label3, "cell 1 3");
        contentPane.add(loanamountTF, "cell 8 3");

        //---- label4 ----
        label4.setText("Enter the number of years to pay");
        contentPane.add(label4, "cell 1 4");
        contentPane.add(yearsTF, "cell 8 4");

        //---- label5 ----
        label5.setText("Enter the loan type: ");
        contentPane.add(label5, "cell 1 5");

        //---- loantypeCB ----
        loantypeCB.setModel(new DefaultComboBoxModel<>(new String[] {
            "Business",
            "Personal "
        }));
        contentPane.add(loantypeCB, "cell 8 5");

        //======== scrollPane1 ========
        {
            scrollPane1.addMouseListener(new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    scrollPane1MousePressed(e);
                }
            });
            scrollPane1.setViewportView(table1);
        }
        contentPane.add(scrollPane1, "cell 1 7");

        //======== scrollPane2 ========
        {
            scrollPane2.setViewportView(table2);
        }
        contentPane.add(scrollPane2, "cell 8 7");

        //---- addBtn ----
        addBtn.setText("Add");
        addBtn.addActionListener(e -> {
            try {
                addBtnActionPerformed(e);
            } catch (ClassNotFoundException | SQLException classNotFoundException) {
                classNotFoundException.printStackTrace();
            }
        });
        contentPane.add(addBtn, "cell 1 8");

        //---- editBtn ----
        editBtn.setText("Edit");
        editBtn.addActionListener(e -> {
            try {
                editBtnActionPerformed(e);
            } catch (ClassNotFoundException | SQLException classNotFoundException) {
                classNotFoundException.printStackTrace();
            }
        });
        contentPane.add(editBtn, "cell 1 8");

        //---- deleteBtn ----
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(e -> {
            try {
                deleteBtnActionPerformed(e);
            } catch (ClassNotFoundException | SQLException classNotFoundException) {
                classNotFoundException.printStackTrace();
            }
        });
        contentPane.add(deleteBtn, "cell 2 8 6 1");

        //---- label6 ----
        label6.setText("Monthly Payment ");
        contentPane.add(label6, "cell 8 8");
        contentPane.add(paymentTF, "cell 8 8");
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - thy nguyen
    private JLabel label1;
    private JTextField clientnoTF;
    private JLabel label2;
    private JTextField clientnameTF;
    private JLabel label3;
    private JTextField loanamountTF;
    private JLabel label4;
    private JTextField yearsTF;
    private JLabel label5;
    private JComboBox<String> loantypeCB;
    private JScrollPane scrollPane1;
    private JTable table1;
    private JScrollPane scrollPane2;
    private JTable table2;
    private JButton addBtn;
    private JButton editBtn;
    private JButton deleteBtn;
    private JLabel label6;
    private JTextField paymentTF;
    // JFormDesigner - End of variables declaration  //GEN-END:variables

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Form1 obj = new Form1();
        obj.setTitle("Loan Projection");
        obj.setVisible(true);
        obj.Prepare();
        obj.updateTable();

       // LoanP obj1 = new LoanP();
    }

    public void Prepare(){
        String[] cols = {"Number", "Name", "Amount", "Years", "Type of Loan"};
        String[][] data = {{"d1.1","d1.2","d1.3","d1.4","d1.5"}};
        DefaultTableModel model = new DefaultTableModel(data,cols);
        table1.setModel(model);
    }


    //method to update table
    public void updateTable() throws ClassNotFoundException, SQLException {
        int c;
        Class.forName("com.mysql.jdbc.Driver");
        con1= DriverManager.getConnection("jdbc:mysql://localhost/loan","root","");

        pst1 = con1.prepareStatement("SELECT * FROM loantable");
        ResultSet rs1= pst1.executeQuery();

        ResultSetMetaData res = rs1.getMetaData();
        c = res.getColumnCount();
        DefaultTableModel df = (DefaultTableModel)table1.getModel();
        df.setRowCount(0);

        while (rs1.next()){

            Vector v2 = new Vector();
            for (int a =1; a<=c; a++){
                v2.add(rs1.getString("clientno"));
                v2.add(rs1.getString("clientname"));
                v2.add(rs1.getString("loanamount"));
                v2.add(rs1.getString("years"));
                v2.add(rs1.getString("loantype"));
            }
            df.addRow(v2);
        }

    }








}
